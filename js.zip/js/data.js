// Mock data for the application
const playlists = [
  {
    id: '1',
    title: "Today's Top Hits",
    description: "Jung Kook is on top of the Hottest 50!",
    imageUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=150&h=150&fit=crop",
    tracks: [
      {
        id: '1-1',
        title: "Standing Next to You",
        artist: "Jung Kook",
        albumCover: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=50&h=50&fit=crop",
        duration: 214
      }
    ]
  },
  {
    id: '2',
    title: "RapCaviar",
    description: "New music from Drake, Travis Scott and more",
    imageUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=150&h=150&fit=crop",
    tracks: [
      {
        id: '2-1',
        title: "First Person Shooter",
        artist: "Drake ft. J. Cole",
        albumCover: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=50&h=50&fit=crop",
        duration: 225
      }
    ]
  },
  {
    id: '3',
    title: "All Out 2010s",
    description: "The biggest songs of the 2010s",
    imageUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=150&h=150&fit=crop",
    tracks: [
      {
        id: '3-1',
        title: "Rolling in the Deep",
        artist: "Adele",
        albumCover: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=50&h=50&fit=crop",
        duration: 228
      }
    ]
  },
  {
    id: '4',
    title: "Rock Classics",
    description: "Rock legends & epic songs",
    imageUrl: "https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=150&h=150&fit=crop",
    tracks: [
      {
        id: '4-1',
        title: "Sweet Child O' Mine",
        artist: "Guns N' Roses",
        albumCover: "https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=50&h=50&fit=crop",
        duration: 356
      }
    ]
  }
];