// Main application logic
document.addEventListener('DOMContentLoaded', () => {
  // Initialize playlists
  renderPlaylists();

  // Initialize player
  const player = new Player();

  // Add hover effects for playlist items
  const addHoverEffects = () => {
    document.querySelectorAll('.featured-item, .recent-item').forEach(item => {
      const playButton = item.querySelector('.play-button');
      
      item.addEventListener('mouseenter', () => {
        if (playButton) playButton.style.opacity = '1';
      });
      
      item.addEventListener('mouseleave', () => {
        if (playButton) playButton.style.opacity = '0';
      });

      if (playButton) {
        playButton.addEventListener('click', (e) => {
          e.stopPropagation();
          const playlistId = item.dataset.playlistId;
          const playlist = playlists.find(p => p.id === playlistId);
          if (playlist && playlist.tracks.length > 0) {
            player.loadTrack(playlist.tracks[0]);
          }
        });
      }
    });
  };

  // Initialize hover effects
  addHoverEffects();

  // Handle theme toggle
  const userBtn = document.querySelector('.user-btn');
  userBtn.addEventListener('click', () => {
    document.body.classList.toggle('dark-theme');
  });
});