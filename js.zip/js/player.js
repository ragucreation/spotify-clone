// Audio player functionality
class Player {
  constructor() {
    this.isPlaying = false;
    this.volume = 0.7;
    this.progress = 0;
    this.currentTrack = null;
    
    this.initializeControls();
    this.initializeHoverEffects();
  }

  loadTrack(track) {
    this.currentTrack = track;
    this.updateTrackInfo();
    this.play();
  }

  updateTrackInfo() {
    if (!this.currentTrack) return;

    const trackName = document.querySelector('.track-name');
    const artistName = document.querySelector('.artist-name');
    const albumCover = document.querySelector('.current-album');

    trackName.textContent = this.currentTrack.title;
    artistName.textContent = this.currentTrack.artist;
    albumCover.src = this.currentTrack.albumCover;
  }

  play() {
    this.isPlaying = true;
    const playBtn = document.querySelector('.play-btn i');
    playBtn.classList.replace('ri-play-fill', 'ri-pause-fill');
    this.startProgressUpdate();
  }

  pause() {
    this.isPlaying = false;
    const playBtn = document.querySelector('.play-btn i');
    playBtn.classList.replace('ri-pause-fill', 'ri-play-fill');
    this.stopProgressUpdate();
  }

  startProgressUpdate() {
    this.progressInterval = setInterval(() => {
      if (this.progress >= 100) {
        this.progress = 0;
        this.pause();
      } else {
        this.progress += 1;
        document.querySelector('.progress').style.width = `${this.progress}%`;
      }
    }, 1000);
  }

  stopProgressUpdate() {
    if (this.progressInterval) {
      clearInterval(this.progressInterval);
    }
  }

  initializeControls() {
    const playBtn = document.querySelector('.play-btn');
    const volumeBar = document.querySelector('.volume-bar');
    const progressContainer = document.querySelector('.progress-container');
    const likeBtn = document.querySelector('.like-btn');

    playBtn.addEventListener('click', () => {
      if (this.isPlaying) {
        this.pause();
      } else {
        this.play();
      }
    });

    volumeBar.addEventListener('click', (e) => {
      const rect = volumeBar.getBoundingClientRect();
      const x = e.clientX - rect.left;
      this.volume = Math.max(0, Math.min(1, x / rect.width));
      volumeBar.querySelector('.volume-level').style.width = `${this.volume * 100}%`;
    });

    progressContainer.addEventListener('click', (e) => {
      const rect = progressContainer.getBoundingClientRect();
      const x = e.clientX - rect.left;
      this.progress = Math.max(0, Math.min(100, (x / rect.width) * 100));
      progressContainer.querySelector('.progress').style.width = `${this.progress}%`;
    });

    likeBtn.addEventListener('click', () => {
      const icon = likeBtn.querySelector('i');
      if (icon.classList.contains('ri-heart-line')) {
        icon.classList.replace('ri-heart-line', 'ri-heart-fill');
        icon.style.color = '#1DB954';
      } else {
        icon.classList.replace('ri-heart-fill', 'ri-heart-line');
        icon.style.color = '';
      }
    });
  }

  initializeHoverEffects() {
    const controlBtns = document.querySelectorAll('.control-btn');
    controlBtns.forEach(btn => {
      btn.addEventListener('mouseenter', () => {
        btn.style.color = '#1DB954';
      });
      
      btn.addEventListener('mouseleave', () => {
        btn.style.color = '';
      });
    });
  }
}