// Playlist management
function renderPlaylists() {
  const playlistsContainer = document.getElementById('playlists');
  const featuredContainer = document.getElementById('featured');
  const recentContainer = document.getElementById('recent');

  // Render sidebar playlists
  playlistsContainer.innerHTML = playlists
    .map(playlist => `
      <li>${playlist.title}</li>
    `)
    .join('');

  // Render featured playlists
  featuredContainer.innerHTML = playlists
    .map(playlist => `
      <div class="featured-item" data-playlist-id="${playlist.id}">
        <img src="${playlist.imageUrl}" alt="${playlist.title}">
        <div class="item-info">
          <h3>${playlist.title}</h3>
        </div>
        <button class="play-button">
          <i class="ri-play-fill"></i>
        </button>
      </div>
    `)
    .join('');

  // Render recent playlists
  recentContainer.innerHTML = playlists
    .map(playlist => `
      <div class="recent-item" data-playlist-id="${playlist.id}">
        <div class="img-container">
          <img src="${playlist.imageUrl}" alt="${playlist.title}">
          <button class="play-button">
            <i class="ri-play-fill"></i>
          </button>
        </div>
        <h3>${playlist.title}</h3>
        <p>${playlist.description}</p>
      </div>
    `)
    .join('');
}