import React from 'react';
import { SpotifyProvider } from './context/SpotifyContext';
import Layout from './components/Layout';

function App() {
  return (
    <SpotifyProvider>
      <Layout />
    </SpotifyProvider>
  );
}

export default App;