import React from 'react';
import Sidebar from './Sidebar';
import MainContent from './MainContent';
import Player from './Player';

const Layout = () => {
  return (
    <div className="flex h-screen bg-black">
      <Sidebar />
      <MainContent />
      <Player />
    </div>
  );
};

export default Layout;