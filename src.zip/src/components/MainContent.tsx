import React from 'react';
import { Play, Clock } from 'lucide-react';

const MainContent = () => {
  const playlists = [
    {
      title: "Today's Top Hits",
      description: "Jung Kook is on top of the Hottest 50!",
      imageUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=150&h=150&fit=crop"
    },
    {
      title: "RapCaviar",
      description: "New music from Drake, Travis Scott and more",
      imageUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=150&h=150&fit=crop"
    },
    {
      title: "All Out 2010s",
      description: "The biggest songs of the 2010s",
      imageUrl: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?w=150&h=150&fit=crop"
    },
    {
      title: "Rock Classics",
      description: "Rock legends & epic songs",
      imageUrl: "https://images.unsplash.com/photo-1498038432885-c6f3f1b912ee?w=150&h=150&fit=crop"
    }
  ];

  return (
    <div className="flex-1 bg-gradient-to-b from-indigo-900 to-black overflow-auto h-screen pb-24">
      <div className="p-8">
        <div className="flex items-center justify-between mb-8">
          <h2 className="text-2xl font-bold text-white">Good afternoon</h2>
        </div>

        <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-8">
          {playlists.map((playlist, index) => (
            <div 
              key={index}
              className="flex items-center bg-white bg-opacity-10 rounded-md hover:bg-opacity-20 transition cursor-pointer group"
            >
              <img 
                src={playlist.imageUrl} 
                alt={playlist.title} 
                className="w-20 h-20 rounded-l-md"
              />
              <div className="p-4 flex-1">
                <h3 className="text-white font-semibold">{playlist.title}</h3>
              </div>
              <button className="opacity-0 group-hover:opacity-100 mr-4 bg-green-500 rounded-full p-3 shadow-lg transition">
                <Play fill="white" size={20} />
              </button>
            </div>
          ))}
        </div>

        <div className="mb-8">
          <h2 className="text-2xl font-bold text-white mb-6">Recently played</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-6">
            {playlists.map((playlist, index) => (
              <div 
                key={index}
                className="bg-gray-900 p-4 rounded-md hover:bg-gray-800 transition cursor-pointer group"
              >
                <div className="relative">
                  <img 
                    src={playlist.imageUrl} 
                    alt={playlist.title} 
                    className="w-full aspect-square object-cover rounded-md mb-4"
                  />
                  <button className="absolute bottom-2 right-2 opacity-0 group-hover:opacity-100 bg-green-500 rounded-full p-3 shadow-lg transition transform translate-y-2 group-hover:translate-y-0">
                    <Play fill="white" size={20} />
                  </button>
                </div>
                <h3 className="text-white font-semibold mb-1">{playlist.title}</h3>
                <p className="text-gray-400 text-sm">{playlist.description}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default MainContent;