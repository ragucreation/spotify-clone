import React from 'react';
import { Play } from 'lucide-react';

interface PlayButtonProps {
  onClick: () => void;
  className?: string;
}

const PlayButton: React.FC<PlayButtonProps> = ({ onClick, className = '' }) => {
  return (
    <button 
      onClick={onClick}
      className={`bg-green-500 rounded-full p-3 shadow-lg transition transform hover:scale-105 ${className}`}
    >
      <Play fill="white" size={20} />
    </button>
  );
};

export default PlayButton;