import React, { createContext, useContext, useState } from 'react';
import { PlaylistType, TrackType } from '../types';
import { playlists as initialPlaylists } from '../data/playlists';

interface SpotifyContextType {
  currentTrack: TrackType | null;
  isPlaying: boolean;
  volume: number;
  playlists: PlaylistType[];
  setCurrentTrack: (track: TrackType) => void;
  togglePlay: () => void;
  setVolume: (volume: number) => void;
}

const SpotifyContext = createContext<SpotifyContextType | undefined>(undefined);

export const SpotifyProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentTrack, setCurrentTrack] = useState<TrackType | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [volume, setVolume] = useState(0.7);
  const [playlists] = useState(initialPlaylists);

  const togglePlay = () => setIsPlaying(prev => !prev);

  const value = {
    currentTrack,
    isPlaying,
    volume,
    playlists,
    setCurrentTrack,
    togglePlay,
    setVolume,
  };

  return (
    <SpotifyContext.Provider value={value}>
      {children}
    </SpotifyContext.Provider>
  );
};

export const useSpotify = () => {
  const context = useContext(SpotifyContext);
  if (context === undefined) {
    throw new Error('useSpotify must be used within a SpotifyProvider');
  }
  return context;
};