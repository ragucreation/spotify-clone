import { PlaylistType } from '../types';

export const playlists: PlaylistType[] = [
  {
    id: '1',
    title: "Today's Top Hits",
    description: "Jung Kook is on top of the Hottest 50!",
    imageUrl: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=150&h=150&fit=crop",
    tracks: [
      {
        id: '1-1',
        title: "Standing Next to You",
        artist: "Jung Kook",
        albumCover: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?w=50&h=50&fit=crop",
        duration: 214
      }
    ]
  },
  {
    id: '2',
    title: "RapCaviar",
    description: "New music from Drake, Travis Scott and more",
    imageUrl: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=150&h=150&fit=crop",
    tracks: [
      {
        id: '2-1',
        title: "First Person Shooter",
        artist: "Drake ft. J. Cole",
        albumCover: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?w=50&h=50&fit=crop",
        duration: 225
      }
    ]
  }
];