import { useState, useEffect } from 'react';
import { useSpotify } from '../context/SpotifyContext';

export const useAudioPlayer = () => {
  const { currentTrack, isPlaying, volume } = useSpotify();
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    if (isPlaying && currentTrack) {
      interval = setInterval(() => {
        setProgress(prev => {
          if (prev >= currentTrack.duration) {
            clearInterval(interval);
            return 0;
          }
          return prev + 1;
        });
      }, 1000);
    }

    return () => {
      if (interval) clearInterval(interval);
    };
  }, [isPlaying, currentTrack]);

  return { progress, setProgress };
};