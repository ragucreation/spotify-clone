export interface PlaylistType {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
  tracks: TrackType[];
}

export interface TrackType {
  id: string;
  title: string;
  artist: string;
  albumCover: string;
  duration: number;
}